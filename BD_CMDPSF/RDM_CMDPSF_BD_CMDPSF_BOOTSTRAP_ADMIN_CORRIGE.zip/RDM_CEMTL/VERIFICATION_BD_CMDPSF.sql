USE [bd_cmdpsf];
GO
SELECT DB_NAME() AS BaseConnectee;
SELECT s.name AS SchemaNom, t.name AS TableNom FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE (s.name='dbo' AND t.name IN ('Professionnel','ProfessionnelCourriel','ProfessionnelTelephone','DocumentProfessionnel')) OR (s.name='ref' AND t.name IN ('Profession','StatutProfessionnel','TitreProfessionnel')) ORDER BY s.name,t.name;
SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='Professionnel' AND COLUMN_NAME IN ('ProfessionnelId','ProfessionId','Permis','Nom','Prenom');
SELECT CodeProfession, Libelle FROM ref.Profession ORDER BY CodeProfession;
