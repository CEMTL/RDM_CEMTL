# Correctif BootstrapAdmin — BD_CMDPSF

Cause : `appsettings.Development.json` surchargeait la valeur définie dans `appsettings.json` avec `BootstrapAdmin: ""`.

Correction : `Authentication:BootstrapAdmin` est maintenant `06CEMTL\\T2-MERA8300` dans les deux fichiers.

Après authentification Active Directory de ce compte, `AccountController` appelle `EnsureBootstrapAdminAsync`, lequel assure sa présence dans les tables `dbo.AspNetUsers`, `dbo.AspNetRoles` et `dbo.AspNetUserRoles` de `bd_cmdpsf`, et lui accorde le rôle Admin. L'accès ne contourne **pas** la validation du mot de passe Active Directory.

Important : les paramètres d'environnement / secrets utilisateur / arguments de configuration ont priorité sur les fichiers JSON. Vérifier `Authentication__BootstrapAdmin` si nécessaire. Vérifier également `ConnectionStrings__RdmConnection` pour garantir que les tables d'identité sont celles de `bd_cmdpsf`.

Si un login est déjà connecté, se déconnecter et se reconnecter. Redémarrer l'application pour relire la configuration.
